/**
 * Created by hariharaselvam on 5/23/17.
 */
window[appName].directive("wmsGoogleChart", function(http, $rootScope, $timeout, pointsGraphService) {
    return {

        restrict: 'EA',

        templateUrl: "/media/js/google_charts_demo/directive/templates/google.chart.tpl.html",

        scope: {
            config: '=config'
        },
        controller: function($scope) {

            $scope.myChartObject = {

                'type': $scope.config.type,
                'data': {},
                'options': {
                    'title': $scope.config.title,
//                    'isStacked': 'relative',
//                    'seriesType': 'area',
                    'focusTarget': 'category',
                    'colors': ['green', 'blue'],
                    'legend': 'none',
//                    'legend': {
//                        position: 'bottom'
//                    },
                    'vAxis': {
                        format: 'short'
                    },
                    'hAxis': {
                        'gridlines': {
                            color: 'transparent'
                        }
                    },
                    'tooltip': {isHtml: true},

                    explorer: {
                        actions: ['dragToZoom', 'rightClickToReset'],
                        axis: 'horizontal',
                        keepInBounds: true,
                        maxZoomIn: 4.0
                    }
                }
            }
            $scope.api = $scope.config.api;
            $scope.myChartObject.data = {};

            $scope.get_data = function() {
                  $scope.myChartObject.data = pointsGraphService.retreivePoints();
//                http.Requests('get', $scope.api, '').success(function(response) {
//
//                    var pivoted = [];
//                    var tooltip = [];
//                    var header = ['Datetime'];
//
//                    for (i = 0; i < response.length; i++) {
//                        header.push(response[i]['name']);
//                    }
//                    //header.push("tooltip");
//                    pivoted.push(header);
//                    for (i = 0; i < response[0]['data'].length; i++) {
//                        pivoted.push([new Date(response[0]['data'][i][0]).toUTCString(), response[0]['data'][i][1], response[1]['data'][i][1]]);
//                    }
//                    //tooltip.push(return 'a')
//                    $scope.myChartObject.data = pivoted;
//                    console.log($scope.myChartObject.data);
//
//                });
            };
            $scope.get_data();
        }

    };
});