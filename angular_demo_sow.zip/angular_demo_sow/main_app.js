/**
 * Created by asm on 8/6/17.
 */
window.appName = "Google_chart_app";
window[appName] = angular.module(appName, ['ui.router', 'ngSanitize', 'googlechart']);

window[appName].controller('google_chart_controller', function ($rootScope, $scope) {

    $rootScope.title = "google_chart_app";

    $scope.home = "Welcome to demo Google charts";
//    $scope.google_bar_chart = {
//        "type" : "PieChart",
//        "page_type" : "bar_google",
//        "api" : "/api/graphs/os/"
//    };
    $scope.throughput = {
        "type" : "AreaChart",
        "page_type" : "area_google",
        "api" : "/api/graphs/throughput/",
//        "stacked":false,
        "title":"Throughput"
    };
    $scope.clientsessions = {
        "type" : "AreaChart",
        "page_type" : "area_google",
        "api" : "/api/graphs/clientsesssions/",
//        "stacked":true,
        "title":"Client Sessions"
    };
    $scope.google_line_chart = {
        "type" : "LineChart",
        "page_type" : "line_google"

    };
    $scope.google_combo_chart = {
        "type" : "ComboChart",
        "page_type" : "combo_google",
        "api" : "/api/graphs/clientsesssions/",
//        "stacked":true,
        "title":"Client Sessions VS Throughput"

    };
    $scope.google_geo_chart = {
        "type" : "GeoChart",
        "page_type" : "geo_google",
//        "data" : [
//    ['Locale', 'Count', 'Percent'],
//    ['Germany', 22, 23],
//    ['United States', 34, 11],
//    ['Brazil', 42, 11],
//    ['Canada', 57, 32],
//    ['France', 6, 9],
//    ['RU', 72, 3]
//  ],
//        "api" : "/api/graphs/clientsesssions/",
//        "stacked":true,
        "title":"Geo chart"

    };

    $scope.google_gauge_chart = {
        "type" : "Gauge",
//        "page_type" : "combo_google",
//        "api" : "/api/graphs/clientsesssions/",
//        "stacked":true,
//        "title":"Client Sessions VS Throughput"

    };

});